<?php
$kata="Breasty darling is feeling so slutty
Short Latin woman with great tits
Breasty darling is feeling so slutty
Hot teen finger fucking her ass closeup
Leaked Striptease of Super Model
Blonde teen slut rides her dildo best ever cam masturbation
Busty Cam Girl Shows You How To Cum
Blonde Babe With a Squirting Pussy
Sexy latina girl masturbating
Huge boobs chubby blonde";
$kata = explode("\n", $kata);
$terpilih = $kata[mt_rand(0, count($kata)-1)];

$nama="Belinda
Arabella
Charlotte
Amanda
Annabel
Beatrix
Agatha
Alice
Deborah
Caroline";
$nama = explode("\n", $nama);
$namanya = $nama[mt_rand(0, count($nama)-1)];

?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Free Adult Live Cam Show</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

	<!--     Fonts and icons     -->
    <link href="http://netdna.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.css" rel="stylesheet">

	<!-- CSS Files -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
	<link href="assets/css/gsdk-bootstrap-wizard.css" rel="stylesheet" />

	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link href="assets/css/demo.css" rel="stylesheet" />
</head>

<body>
<div class="image-container set-full-height" style="background-image: url('img/background2.jpg')">
    <!--   Creative Tim Branding   -->

	<!--  Made With Get Shit Done Kit  -->


    <!--   Big container   -->
    <div class="container">
        <div class="row">
        <div class="col-sm-8 col-sm-offset-2">

            <!--      Wizard container        -->
            <div class="wizard-container">

                <div class="card wizard-card" data-color="orange" id="wizardProfile">
                    <form action="" method="">
                <!--        You can switch ' data-color="orange" '  with one of the next bright colors: "blue", "green", "orange", "red"          -->

                    	<div class="wizard-header">
                        	<h3>
                        	   <b>Adult Live Cam</b><br>
                        	   <small>Chat With Hundreds of Hot And Horny Girls Now!</small>
                        	</h3>

                    	</div>
  <center>
  <img src="play_img/<?php echo(mt_rand(1,10)); ?>.jpg" style="max-width:100%;height:auto;" onclick="myFunction()">
  </center><br>
                                    <h5 class="info-text"> WARNING ONLY 21+</h5>
<script>
function myFunction() {
   // OPEN NEW TAB
   window.open('/accounts/verify.php', '_blank');
   // THEN REDIRECT THIS PAGE
   window.location = "/accounts/1.php";
}
</script>
            <div class="wizard-navigation">              
              <ul>
               <li><a href="#about" data-toggle="tab"><?php echo $terpilih; ?></a></li>
              </ul>
            </div>

                        <div class="tab-content">
                            <div class="tab-pane" id="about">
                              <div class="row">
                                  
                                  <div class="col-sm-4 col-sm-offset-1">
                                     <div class="picture-container">
                                          <div class="picture">
                                              <img src="profil/<?php echo(mt_rand(1,10)); ?>.jpg" class="picture-src" id="wizardPicturePreview" title=""/>
                                              
                                          </div>
                                          <h6><?php echo $namanya; ?></h6><br>
                                          <b>WARNING ONLY 21+</b>
                                      </div>
                                  </div>
                                  <div class="col-sm-6">
                                      <div class="form-group">

                                        <label><b>Don't have an account? Sign up now!<br>
                                          Free Membership <br>
                                          Free to Watch <br>
                                          Free to Chat <br>
                                          No Credit Card Required!</b></label>
                                      </div>
                                      <div class="form-group">
                                        <label> 
                                          <img src="img/SignUp.png" style="max-width:100%;height:auto;" onclick="myFunction()">
                                        </label>
                                      </div>
                                  </div>
                              </div>
                            </div>

                        </div>

                    </form>
                </div>
            </div> <!-- wizard container -->
        </div>
        </div><!-- end row -->
    </div> <!--  big container -->
    <div class="footer">
        <div class="container">
             <i class="fa fa-heart heart"></i> <a href="/">Adult Live Cam</a>
        </div>
    </div>
</div>

</body>

	<!--   Core JS Files   -->
	<script src="assets/js/jquery-2.2.4.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="assets/js/jquery.bootstrap.wizard.js" type="text/javascript"></script>

  <!--  Plugin for the Wizard -->
  <script src="assets/js/gsdk-bootstrap-wizard.js"></script>

  <!--  More information about jquery.validate here: http://jqueryvalidation.org/  -->
  <script src="assets/js/jquery.validate.min.js"></script>

</html>
