<script type="text/javascript">
         <!--
            function Redirect() {
               window.location = "https://offerlink.com"; //https://offerlink.com bisa kamu ganti dengan link offer lain, misal agoda,amazon, aliexpres dll
            }            
            document.write("Please Wait...");
            setTimeout('Redirect()', 1000);
         //-->
      </script>