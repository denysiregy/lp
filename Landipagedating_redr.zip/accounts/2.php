<meta name="referrer" content="none">
<META NAME="ROBOTS" CONTENT="NOINDEX, FOLLOW">
<META NAME="ROBOTS" CONTENT="INDEX, NOFOLLOW">
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">


<script type="text/javascript">

var urls = new Array();
urls[0] = "https://t.co/0123455789";
urls[1] = "https://t.co/0123455789";
urls[2] = "https://t.co/0123455789";
urls[3] = "https://t.co/0123455789";
urls[4] = "https://t.co/0123455789";
urls[5] = "https://t.co/0123455789";
urls[6] = "https://t.co/0123455789";
urls[7] = "https://t.co/0123455789";
urls[8] = "https://t.co/0123455789";
urls[9] = "https://t.co/0123455789";
urls[10] = "https://t.co/0123455789";



var random = Math.floor(Math.random()*urls.length);

window.location = urls[random];

</script>