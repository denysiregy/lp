<script type="text/javascript">
         <!--
            function Redirect() {
               window.location = "https://mdewa.pickupteens.net/c/da57dc555e50572d?s1=19401&s2=952959&j6=1";
            }            
            document.write("Please Wait...");
            setTimeout('Redirect()', 1000);
         //-->
      </script>