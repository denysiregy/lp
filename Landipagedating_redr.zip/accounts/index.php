<?php
    /*
    |--------------------------------------------------------------------------
    | List Country ID = https://countrycode.org/
    |--------------------------------------------------------------------------
    | example atau contoh below:
    | $uri_affilate = 'http://www.google.com';
    */
function get_client_ip() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER["HTTP_CF_CONNECTING_IP"])) 
        $ipaddress = $_SERVER["HTTP_CF_CONNECTING_IP"];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else
        $ipaddress = 'UNKNOWN';
    $geord = @json_decode(@file_get_contents('http://www.geoplugin.net/json.gp?ip='.$ipaddress));
    return $geord;
}
$countryCode = get_client_ip()->geoplugin_countryCode;

if ( $countryCode == "US" || $countryCode == "FR" || $countryCode == "GB" || $countryCode == "ES" || $countryCode == "IT" || $countryCode == "PT" || $countryCode == "JP" || $countryCode == "KP" || $countryCode == "KR" || $countryCode == "AU" || $countryCode == "SG" ) {
    $uri_affilate = '/accounts/dating1.php';
} elseif ( $countryCode == "US" ) {
    $uri_affilate = '/accounts/dating1.php';
} elseif ( $countryCode == "US" ) {
    $uri_affilate = '/accounts/dating1.php';
} elseif ( $countryCode == "US" ) {
    $uri_affilate = '/accounts/dating1.php';
} elseif ( $countryCode == "US" ) {
    $uri_affilate = '/accounts/dating1.php';
} else {
    $uri_affilate = '/accounts/dating2.php';
}
header("Location: $uri_affilate");
?>