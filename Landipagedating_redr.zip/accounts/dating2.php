<script type="text/javascript">
         <!--
            function Redirect() {
               window.location = "https://domain.blogspot.com";
            }            
            document.write("Please Wait...");
            setTimeout('Redirect()', 1000);
         //-->
      </script>